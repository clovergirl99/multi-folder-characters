export type FolderMemberships = Record<string, string[]>

export function normalizeFolderName(value: unknown): string | null {
  if (typeof value !== 'string') return null
  const name = value.trim()
  return name && name.toLocaleLowerCase() !== 'uncategorized' ? name : null
}

export function normalizeMemberships(value: unknown): FolderMemberships {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {}
  const result: FolderMemberships = {}
  for (const [characterId, rawFolders] of Object.entries(value as Record<string, unknown>)) {
    if (!characterId.trim() || !Array.isArray(rawFolders)) continue
    const seen = new Set<string>()
    const folders: string[] = []
    for (const rawFolder of rawFolders) {
      const folder = normalizeFolderName(rawFolder)
      if (!folder) continue
      const key = folder.toLocaleLowerCase()
      if (seen.has(key)) continue
      seen.add(key)
      folders.push(folder)
    }
    if (folders.length) result[characterId] = folders
  }
  return result
}

export function secondaryFolders(characterId: string, primaryFolder: string, memberships: FolderMemberships): string[] {
  const primaryKey = primaryFolder.trim().toLocaleLowerCase()
  return (memberships[characterId] ?? []).filter((folder) => folder.toLocaleLowerCase() !== primaryKey)
}

export function charactersForFolder<T extends { id: string; folder?: string }>(characters: readonly T[], folder: string, memberships: FolderMemberships): T[] {
  const folderKey = folder.toLocaleLowerCase()
  return characters.filter((character) => {
    if ((character.folder ?? '').trim().toLocaleLowerCase() === folderKey) return false
    return secondaryFolders(character.id, character.folder ?? '', memberships).some((candidate) => candidate.toLocaleLowerCase() === folderKey)
  })
}
