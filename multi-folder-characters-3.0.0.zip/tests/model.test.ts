import { describe, expect, test } from 'bun:test'
import { charactersForFolder, normalizeMemberships, secondaryFolders } from '../src/model'

describe('multi-folder membership model', () => {
  test('normalizes duplicate and invalid folder names', () => {
    expect(normalizeMemberships({ a: [' Story ', 'story', '', 'Uncategorized'], b: 'nope' }))
      .toEqual({ a: ['Story'] })
  })

  test('never duplicates a character in its primary folder', () => {
    const memberships = { a: ['Story', 'Favorites'] }
    expect(secondaryFolders('a', 'Story', memberships)).toEqual(['Favorites'])
  })

  test('selects only secondary members for a folder', () => {
    const characters = [{ id: 'a', folder: 'Story' }, { id: 'b', folder: 'Other' }]
    const memberships = { a: ['Favorites'], b: ['Story'] }
    expect(charactersForFolder(characters, 'Story', memberships).map(({ id }) => id)).toEqual(['b'])
    expect(charactersForFolder(characters, 'Favorites', memberships).map(({ id }) => id)).toEqual(['a'])
  })
})
